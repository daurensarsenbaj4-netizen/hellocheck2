package com.example.hellocheck

import android.content.Intent
import android.os.Bundle
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import com.example.hellocheck.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Init and start music at 50%
        MusicManager.init(this)
        MusicManager.setVolume(50)
        MusicManager.start()
        updateMusicButton()

        binding.seekVolume.progress = 50
        binding.seekVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    MusicManager.setVolume(progress)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.btnMusicToggle.setOnClickListener {
            MusicManager.toggle()
            updateMusicButton()
        }

        binding.btnStart.setOnClickListener {
            startActivity(Intent(this, CaptchaActivity::class.java))
        }
    }

    private fun updateMusicButton() {
        binding.btnMusicToggle.text = if (MusicManager.isPlaying) {
            getString(R.string.music_on)
        } else {
            getString(R.string.music_off)
        }
    }

    override fun onResume() {
        super.onResume()
        updateMusicButton()
        binding.seekVolume.progress = (MusicManager.volume * 100).toInt()
    }

    override fun onDestroy() {
        // Do not release here so music continues in CaptchaActivity
        super.onDestroy()
    }
}
