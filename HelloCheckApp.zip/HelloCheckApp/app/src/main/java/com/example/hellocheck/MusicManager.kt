package com.example.hellocheck

import android.content.Context
import android.media.MediaPlayer
import android.media.AudioAttributes

object MusicManager {
    private var mediaPlayer: MediaPlayer? = null
    private var isPrepared = false
    var isPlaying: Boolean = false
        private set
    var volume: Float = 0.5f
        private set

    fun init(context: Context) {
        if (mediaPlayer == null) {
            mediaPlayer = MediaPlayer.create(context.applicationContext, R.raw.background_music).apply {
                isLooping = true
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                setVolume(volume, volume)
            }
            isPrepared = true
        }
    }

    fun start() {
        mediaPlayer?.let {
            if (!it.isPlaying) {
                it.start()
                isPlaying = true
            }
        }
    }

    fun pause() {
        mediaPlayer?.let {
            if (it.isPlaying) {
                it.pause()
                isPlaying = false
            }
        }
    }

    fun toggle(): Boolean {
        if (isPlaying) {
            pause()
        } else {
            start()
        }
        return isPlaying
    }

    fun setVolume(progress: Int) {
        volume = (progress.coerceIn(0, 100) / 100f)
        mediaPlayer?.setVolume(volume, volume)
    }

    fun release() {
        mediaPlayer?.release()
        mediaPlayer = null
        isPrepared = false
        isPlaying = false
    }
}
