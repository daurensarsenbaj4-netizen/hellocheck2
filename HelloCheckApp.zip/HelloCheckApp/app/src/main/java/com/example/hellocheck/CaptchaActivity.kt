package com.example.hellocheck

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.hellocheck.databinding.ActivityCaptchaBinding
import kotlin.random.Random

class CaptchaActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCaptchaBinding
    private val handler = Handler(Looper.getMainLooper())
    private var currentChallenge: Challenge? = null
    private var lastType: Int = -1
    private var round = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCaptchaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        MusicManager.init(this)
        if (!MusicManager.isPlaying) {
            MusicManager.start()
        }
        updateMusicButton()
        binding.seekVolume.progress = (MusicManager.volume * 100).toInt()

        binding.seekVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) MusicManager.setVolume(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.btnMusicToggle.setOnClickListener {
            MusicManager.toggle()
            updateMusicButton()
        }

        binding.btnSubmit.setOnClickListener {
            checkAnswer()
        }

        showNextChallenge()
    }

    private fun updateMusicButton() {
        binding.btnMusicToggle.text = if (MusicManager.isPlaying) {
            getString(R.string.music_on)
        } else {
            getString(R.string.music_off)
        }
    }

    private fun showNextChallenge() {
        round++
        binding.tvFeedback.visibility = View.GONE
        binding.btnSubmit.visibility = View.GONE
        binding.dynamicContent.removeAllViews()

        // Choose different type from last
        var type: Int
        do {
            type = Random.nextInt(0, 6)
        } while (type == lastType && round > 1)
        lastType = type

        currentChallenge = when (type) {
            0 -> createMathChallenge()
            1 -> createColorChallenge()
            2 -> createWordChallenge()
            3 -> createSequenceChallenge()
            4 -> createOddOneOutChallenge()
            else -> createCountChallenge()
        }

        binding.tvChallengeTitle.text = "Проверка #$round"
        binding.tvChallengeDesc.text = currentChallenge?.description ?: ""
        currentChallenge?.buildUI(binding.dynamicContent)

        if (currentChallenge?.needsSubmit == true) {
            binding.btnSubmit.visibility = View.VISIBLE
        }
    }

    private fun checkAnswer() {
        val correct = currentChallenge?.check() ?: false
        if (correct) {
            binding.tvFeedback.text = getString(R.string.correct)
            binding.tvFeedback.setTextColor(ContextCompat.getColor(this, R.color.success))
            binding.tvFeedback.visibility = View.VISIBLE
            binding.btnSubmit.isEnabled = false
            handler.postDelayed({
                binding.btnSubmit.isEnabled = true
                showNextChallenge()
            }, 1500)
        } else {
            binding.tvFeedback.text = getString(R.string.incorrect)
            binding.tvFeedback.setTextColor(ContextCompat.getColor(this, R.color.error))
            binding.tvFeedback.visibility = View.VISIBLE
        }
    }

    // ========== Challenges ==========

    private abstract class Challenge(
        val description: String,
        val needsSubmit: Boolean = true
    ) {
        abstract fun buildUI(container: ViewGroup)
        abstract fun check(): Boolean
    }

    private fun createMathChallenge(): Challenge {
        val a = Random.nextInt(2, 20)
        val b = Random.nextInt(2, 15)
        val op = if (Random.nextBoolean()) "+" else "×"
        val answer = if (op == "+") a + b else a * b
        var editText: EditText? = null

        return object : Challenge("Решите пример:\n$a $op $b = ?") {
            override fun buildUI(container: ViewGroup) {
                editText = EditText(this@CaptchaActivity).apply {
                    inputType = InputType.TYPE_CLASS_NUMBER
                    hint = "Ваш ответ"
                    setTextColor(Color.WHITE)
                    setHintTextColor(Color.LTGRAY)
                    textSize = 18f
                    gravity = Gravity.CENTER
                    setBackgroundColor(Color.parseColor("#33FFFFFF"))
                    setPadding(24, 24, 24, 24)
                }
                container.addView(editText, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }
            override fun check(): Boolean {
                val user = editText?.text?.toString()?.toIntOrNull()
                return user == answer
            }
        }
    }

    private fun createColorChallenge(): Challenge {
        val colors = listOf(
            "Красный" to Color.RED,
            "Зелёный" to Color.GREEN,
            "Синий" to Color.BLUE,
            "Жёлтый" to Color.YELLOW,
            "Оранжевый" to Color.parseColor("#FF9800"),
            "Фиолетовый" to Color.parseColor("#9C27B0")
        )
        val target = colors.random()
        var selected: String? = null
        val buttons = mutableListOf<Button>()

        return object : Challenge("Нажмите на кнопку цвета «${target.first}»", needsSubmit = false) {
            override fun buildUI(container: ViewGroup) {
                val grid = LinearLayout(this@CaptchaActivity).apply {
                    orientation = LinearLayout.VERTICAL
                }
                colors.shuffled().chunked(2).forEach { rowColors ->
                    val row = LinearLayout(this@CaptchaActivity).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER
                    }
                    rowColors.forEach { (name, color) ->
                        val btn = Button(this@CaptchaActivity).apply {
                            text = name
                            setBackgroundColor(color)
                            setTextColor(if (color == Color.YELLOW || color == Color.GREEN) Color.BLACK else Color.WHITE)
                            setOnClickListener {
                                selected = name
                                // Visual feedback
                                buttons.forEach { it.alpha = 0.5f }
                                this.alpha = 1f
                                // Auto check after short delay
                                handler.postDelayed({
                                    if (selected == target.first) {
                                        binding.tvFeedback.text = getString(R.string.correct)
                                        binding.tvFeedback.setTextColor(ContextCompat.getColor(this@CaptchaActivity, R.color.success))
                                        binding.tvFeedback.visibility = View.VISIBLE
                                        handler.postDelayed({ showNextChallenge() }, 1200)
                                    } else {
                                        binding.tvFeedback.text = getString(R.string.incorrect)
                                        binding.tvFeedback.setTextColor(ContextCompat.getColor(this@CaptchaActivity, R.color.error))
                                        binding.tvFeedback.visibility = View.VISIBLE
                                        this.alpha = 0.5f
                                    }
                                }, 300)
                            }
                        }
                        buttons.add(btn)
                        row.addView(btn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                            setMargins(8, 8, 8, 8)
                        })
                    }
                    grid.addView(row)
                }
                container.addView(grid)
            }
            override fun check() = selected == target.first
        }
    }

    private fun createWordChallenge(): Challenge {
        val words = listOf("космос", "звезда", "планета", "ракета", "галактика", "орбита", "комета", "небо")
        val target = words.random()
        var editText: EditText? = null

        return object : Challenge("Введите слово, которое написано ниже:\n\n«$target»") {
            override fun buildUI(container: ViewGroup) {
                editText = EditText(this@CaptchaActivity).apply {
                    inputType = InputType.TYPE_CLASS_TEXT
                    hint = "Введите слово"
                    setTextColor(Color.WHITE)
                    setHintTextColor(Color.LTGRAY)
                    textSize = 18f
                    gravity = Gravity.CENTER
                    setBackgroundColor(Color.parseColor("#33FFFFFF"))
                    setPadding(24, 24, 24, 24)
                }
                container.addView(editText, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }
            override fun check(): Boolean {
                return editText?.text?.toString()?.trim()?.equals(target, ignoreCase = true) == true
            }
        }
    }

    private fun createSequenceChallenge(): Challenge {
        val sequence = listOf(1, 2, 3, 4).shuffled()
        val userOrder = mutableListOf<Int>()
        val buttons = mutableListOf<Button>()

        return object : Challenge("Нажмите кнопки в порядке: ${sequence.joinToString(" → ")}", needsSubmit = false) {
            override fun buildUI(container: ViewGroup) {
                val layout = LinearLayout(this@CaptchaActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER
                }
                sequence.forEach { num ->
                    val btn = Button(this@CaptchaActivity).apply {
                        text = num.toString()
                        textSize = 22f
                        setOnClickListener {
                            if (!userOrder.contains(num)) {
                                userOrder.add(num)
                                this.isEnabled = false
                                this.alpha = 0.4f
                                if (userOrder.size == sequence.size) {
                                    handler.postDelayed({
                                        if (userOrder == sequence) {
                                            binding.tvFeedback.text = getString(R.string.correct)
                                            binding.tvFeedback.setTextColor(ContextCompat.getColor(this@CaptchaActivity, R.color.success))
                                            binding.tvFeedback.visibility = View.VISIBLE
                                            handler.postDelayed({ showNextChallenge() }, 1200)
                                        } else {
                                            binding.tvFeedback.text = getString(R.string.incorrect)
                                            binding.tvFeedback.setTextColor(ContextCompat.getColor(this@CaptchaActivity, R.color.error))
                                            binding.tvFeedback.visibility = View.VISIBLE
                                            // Reset
                                            userOrder.clear()
                                            buttons.forEach {
                                                it.isEnabled = true
                                                it.alpha = 1f
                                            }
                                        }
                                    }, 400)
                                }
                            }
                        }
                    }
                    buttons.add(btn)
                    layout.addView(btn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                        setMargins(6, 6, 6, 6)
                    })
                }
                container.addView(layout)
            }
            override fun check() = userOrder == sequence
        }
    }

    private fun createOddOneOutChallenge(): Challenge {
        val items = listOf("⭐", "🌟", "✨", "🌙", "☀️", "🪐")
        val odd = items.random()
        val normal = (items - odd).random()
        val display = MutableList(5) { normal }
        val oddPos = Random.nextInt(5)
        display[oddPos] = odd
        var selectedPos: Int? = null

        return object : Challenge("Найдите лишний элемент (отличающийся)", needsSubmit = false) {
            override fun buildUI(container: ViewGroup) {
                val layout = LinearLayout(this@CaptchaActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER
                }
                display.forEachIndexed { index, emoji ->
                    val tv = TextView(this@CaptchaActivity).apply {
                        text = emoji
                        textSize = 36f
                        gravity = Gravity.CENTER
                        setPadding(16, 16, 16, 16)
                        setOnClickListener {
                            selectedPos = index
                            if (index == oddPos) {
                                binding.tvFeedback.text = getString(R.string.correct)
                                binding.tvFeedback.setTextColor(ContextCompat.getColor(this@CaptchaActivity, R.color.success))
                                binding.tvFeedback.visibility = View.VISIBLE
                                handler.postDelayed({ showNextChallenge() }, 1200)
                            } else {
                                binding.tvFeedback.text = getString(R.string.incorrect)
                                binding.tvFeedback.setTextColor(ContextCompat.getColor(this@CaptchaActivity, R.color.error))
                                binding.tvFeedback.visibility = View.VISIBLE
                            }
                        }
                    }
                    layout.addView(tv)
                }
                container.addView(layout)
            }
            override fun check() = selectedPos == oddPos
        }
    }

    private fun createCountChallenge(): Challenge {
        val count = Random.nextInt(3, 8)
        val emoji = listOf("⭐", "🌟", "✨", "🪐").random()
        var editText: EditText? = null

        return object : Challenge("Сколько здесь символов «$emoji»?\n\n${emoji.repeat(count)}") {
            override fun buildUI(container: ViewGroup) {
                editText = EditText(this@CaptchaActivity).apply {
                    inputType = InputType.TYPE_CLASS_NUMBER
                    hint = "Введите число"
                    setTextColor(Color.WHITE)
                    setHintTextColor(Color.LTGRAY)
                    textSize = 18f
                    gravity = Gravity.CENTER
                    setBackgroundColor(Color.parseColor("#33FFFFFF"))
                    setPadding(24, 24, 24, 24)
                }
                container.addView(editText, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }
            override fun check(): Boolean {
                return editText?.text?.toString()?.toIntOrNull() == count
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updateMusicButton()
        binding.seekVolume.progress = (MusicManager.volume * 100).toInt()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
